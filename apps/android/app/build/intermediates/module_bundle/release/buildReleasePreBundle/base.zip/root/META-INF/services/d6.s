e6.b
